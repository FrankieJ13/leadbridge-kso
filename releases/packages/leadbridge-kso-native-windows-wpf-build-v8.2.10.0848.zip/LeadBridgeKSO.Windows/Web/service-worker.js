importScripts('./src/security.js');

const CACHE_NAME = 'leadbridge-kso-pwa-v8.2.10.0848-7';
const APP_SHELL = [
  './index.html',
  './app.css',
  './app.js',
  './src/security.js',
  './src/csv.js',
  './src/matching.js',
  './src/amo-schema.js',
  './src/online-csv.js',
  './manifest.webmanifest',
  './icons/icon.svg',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './releases/manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => Promise.all(APP_SHELL.map((url) =>
        fetch(url, {cache: 'reload'}).then((response) => {
          if (!response.ok) throw new Error(`failed to cache ${url}`);
          return cache.put(url, response);
        })
      )))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        LeadBridgeSecurity.cacheKeysToDelete(keys, CACHE_NAME).map((key) => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const {request} = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.includes('/releases/packages/')) return;

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(new Request(request, {cache: 'reload'}))
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put('./index.html', copy));
          return response;
        })
        .catch(() => caches.match('./index.html'))
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request).then((response) => {
        if (response.ok && response.type === 'basic') {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
        }
        return response;
      });
    })
  );
});
