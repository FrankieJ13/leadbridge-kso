$ErrorActionPreference = 'Stop'

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageDownloadUrl = 'https://frankiej13.github.io/leadbridge-kso/releases/packages/leadbridge-kso-tools-windows-v8.2.10.0848.zip'

function Test-LeadBridgePayload($Path) {
  if (-not $Path -or -not (Test-Path $Path -PathType Container)) {
    return $false
  }

  $RepoPayload = (
    (Test-Path (Join-Path $Path 'apps\leadbridge-web') -PathType Container) -and
    (Test-Path (Join-Path $Path 'apps\max-chat-local-exporter') -PathType Container) -and
    (Test-Path (Join-Path $Path 'apps\max-chat-ocr-postprocessor') -PathType Container) -and
    (Test-Path (Join-Path $Path 'tools\ocr-bridge') -PathType Container) -and
    (Test-Path (Join-Path $Path 'tools\launcher') -PathType Container)
  )
  $PackPayload = (
    (Test-Path (Join-Path $Path 'tools\leadbridge') -PathType Container) -and
    (Test-Path (Join-Path $Path 'tools\max-chat-local-exporter') -PathType Container) -and
    (Test-Path (Join-Path $Path 'tools\max-chat-ocr-postprocessor') -PathType Container) -and
    (Test-Path (Join-Path $Path 'tools\ocr-bridge') -PathType Container) -and
    (Test-Path (Join-Path $Path 'launchers') -PathType Container)
  )

  return ($RepoPayload -or $PackPayload)
}

function Find-LeadBridgePayload($StartPath) {
  $Candidates = New-Object System.Collections.Generic.List[string]
  [void]$Candidates.Add($StartPath)

  $Parent = Split-Path -Parent $StartPath
  if ($Parent) {
    [void]$Candidates.Add($Parent)
    $GrandParent = Split-Path -Parent $Parent
    if ($GrandParent) {
      [void]$Candidates.Add($GrandParent)
    }
  }

  $Children = @(Get-ChildItem -Path $StartPath -Directory -ErrorAction SilentlyContinue)
  foreach ($Child in $Children) {
    [void]$Candidates.Add($Child.FullName)
    foreach ($GrandChild in @(Get-ChildItem -Path $Child.FullName -Directory -ErrorAction SilentlyContinue)) {
      [void]$Candidates.Add($GrandChild.FullName)
    }
  }

  foreach ($Candidate in @($Candidates | Select-Object -Unique)) {
    if (Test-LeadBridgePayload $Candidate) {
      return (Resolve-Path $Candidate).Path
    }
  }
  return $null
}

$SourceRoot = Find-LeadBridgePayload $ScriptDir
$Target = 'C:\LeadBridgeKSO'

Write-Host 'LeadBridge KSO Windows installer' -ForegroundColor Green
Write-Host "Target: $Target"

if (-not $SourceRoot) {
  Write-Host ''
  Write-Host 'The complete LeadBridge tools pack was not found next to this installer.' -ForegroundColor Red
  Write-Host 'Do not copy install_windows.ps1 out of the extracted package.' -ForegroundColor Yellow
  Write-Host 'Download and extract the complete Windows ZIP:' -ForegroundColor Yellow
  Write-Host $PackageDownloadUrl -ForegroundColor Cyan
  Write-Host 'Then open the LeadBridgeKSO-Windows-v8.2.10.0848 folder and run its install_windows.ps1.'
  exit 2
}

Write-Host "Source: $SourceRoot"

New-Item -ItemType Directory -Force -Path $Target | Out-Null
New-Item -ItemType Directory -Force -Path "$Target\exports" | Out-Null
New-Item -ItemType Directory -Force -Path "$Target\ocr_results" | Out-Null
New-Item -ItemType Directory -Force -Path "$Target\tools" | Out-Null
New-Item -ItemType Directory -Force -Path "$Target\integrations" | Out-Null
New-Item -ItemType Directory -Force -Path "$Target\archives" | Out-Null
New-Item -ItemType Directory -Force -Path "$Target\launchers" | Out-Null

function Copy-CleanDir($Source, $Destination) {
  if (-not (Test-Path $Source -PathType Container)) {
    throw "Required package folder is missing: $Source"
  }
  if (Test-Path $Destination) {
    Remove-Item $Destination -Recurse -Force
  }
  New-Item -ItemType Directory -Force -Path $Destination | Out-Null
  Copy-Item (Join-Path $Source '*') $Destination -Recurse -Force
}

if (Test-Path (Join-Path $SourceRoot 'apps\leadbridge-web')) {
  Copy-CleanDir (Join-Path $SourceRoot 'apps\leadbridge-web') "$Target\tools\leadbridge"
} else {
  Copy-CleanDir (Join-Path $SourceRoot 'tools\leadbridge') "$Target\tools\leadbridge"
}

if (Test-Path (Join-Path $SourceRoot 'apps\max-chat-local-exporter')) {
  Copy-CleanDir (Join-Path $SourceRoot 'apps\max-chat-local-exporter') "$Target\tools\max-chat-local-exporter"
} else {
  Copy-CleanDir (Join-Path $SourceRoot 'tools\max-chat-local-exporter') "$Target\tools\max-chat-local-exporter"
}

if (Test-Path (Join-Path $SourceRoot 'apps\max-chat-ocr-postprocessor')) {
  Copy-CleanDir (Join-Path $SourceRoot 'apps\max-chat-ocr-postprocessor') "$Target\tools\max-chat-ocr-postprocessor"
} else {
  Copy-CleanDir (Join-Path $SourceRoot 'tools\max-chat-ocr-postprocessor') "$Target\tools\max-chat-ocr-postprocessor"
}

Copy-CleanDir (Join-Path $SourceRoot 'tools\ocr-bridge') "$Target\tools\ocr-bridge"

if (Test-Path (Join-Path $SourceRoot 'integrations\google-apps-script-amocrm')) {
  Copy-CleanDir (Join-Path $SourceRoot 'integrations\google-apps-script-amocrm') "$Target\integrations\google-apps-script-amocrm"
}

if (Test-Path (Join-Path $SourceRoot 'releases\packages')) {
  Copy-Item (Join-Path $SourceRoot 'releases\packages\*') "$Target\archives" -Recurse -Force
} elseif (Test-Path (Join-Path $SourceRoot 'archives')) {
  Copy-Item (Join-Path $SourceRoot 'archives\*') "$Target\archives" -Recurse -Force
}

if (Test-Path (Join-Path $SourceRoot 'tools\launcher')) {
  Copy-Item (Join-Path $SourceRoot 'tools\launcher\open_leadbridge_windows.bat') "$Target\launchers\open_leadbridge.bat" -Force
  Copy-Item (Join-Path $SourceRoot 'tools\launcher\run_ocr_windows.bat') "$Target\launchers\run_ocr_windows.bat" -Force
} elseif (Test-Path (Join-Path $SourceRoot 'launchers')) {
  Copy-Item (Join-Path $SourceRoot 'launchers\open_leadbridge.bat') "$Target\launchers\open_leadbridge.bat" -Force
  Copy-Item (Join-Path $SourceRoot 'launchers\run_ocr_windows.bat') "$Target\launchers\run_ocr_windows.bat" -Force
}

if (Test-Path (Join-Path $SourceRoot 'README_FIRST.txt')) {
  Copy-Item (Join-Path $SourceRoot 'README_FIRST.txt') "$Target\README_FIRST.txt" -Force
} elseif (Test-Path (Join-Path $SourceRoot 'README.md')) {
  Copy-Item (Join-Path $SourceRoot 'README.md') "$Target\README_FIRST.txt" -Force
}

function Find-PythonCommand {
  $Candidates = New-Object System.Collections.Generic.List[string]
  foreach ($Name in @('py', 'python')) {
    $Command = Get-Command $Name -ErrorAction SilentlyContinue
    if ($Command -and $Command.Source) {
      [void]$Candidates.Add($Command.Source)
    }
  }

  foreach ($Pattern in @(
    "$env:LocalAppData\Programs\Python\Python*\python.exe",
    "$env:ProgramFiles\Python*\python.exe"
  )) {
    foreach ($File in @(Get-ChildItem -Path $Pattern -File -ErrorAction SilentlyContinue | Sort-Object FullName -Descending)) {
      [void]$Candidates.Add($File.FullName)
    }
  }

  foreach ($Candidate in @($Candidates | Select-Object -Unique)) {
    try {
      $Version = (& $Candidate --version 2>&1 | Out-String).Trim()
      if ($LASTEXITCODE -eq 0 -and $Version -match '^Python 3\.(?:1[0-9]|[2-9][0-9])') {
        return $Candidate
      }
    } catch {
      continue
    }
  }
  return $null
}

$InstallExitCode = 0
$Python = Find-PythonCommand
if (-not $Python -and (Get-Command winget -ErrorAction SilentlyContinue)) {
  Write-Host 'Python 3.12 not found. Installing it via winget...' -ForegroundColor Cyan
  winget install --id Python.Python.3.12 -e --scope user --accept-package-agreements --accept-source-agreements
  if ($LASTEXITCODE -eq 0) {
    $Python = Find-PythonCommand
  }
}

if ($Python) {
  Write-Host "Python found: $Python" -ForegroundColor Green
  Write-Host 'Installing Python requirements...' -ForegroundColor Cyan
  & $Python -m ensurepip --upgrade
  & $Python -m pip install -r "$Target\tools\max-chat-ocr-postprocessor\requirements.txt"
  if ($LASTEXITCODE -ne 0) {
    Write-Host 'Python requirements installation failed.' -ForegroundColor Red
    $InstallExitCode = 2
  }
} else {
  Write-Host 'Python 3.12 could not be installed automatically.' -ForegroundColor Red
  Write-Host 'Run this command, reopen PowerShell, then run install_windows.ps1 again:' -ForegroundColor Yellow
  Write-Host 'winget install --id Python.Python.3.12 -e --scope user' -ForegroundColor Cyan
  $InstallExitCode = 2
}

$Tesseract = Get-Command tesseract -ErrorAction SilentlyContinue
if (-not $Tesseract -and (Test-Path 'C:\Program Files\Tesseract-OCR\tesseract.exe' -PathType Leaf)) {
  $Tesseract = Get-Item 'C:\Program Files\Tesseract-OCR\tesseract.exe'
}

if (-not $Tesseract) {
  Write-Host 'Tesseract not found.' -ForegroundColor Yellow
  if (Get-Command winget -ErrorAction SilentlyContinue) {
    Write-Host 'Trying to install Tesseract via winget...' -ForegroundColor Cyan
    winget install --id UB-Mannheim.TesseractOCR -e --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
      Write-Host 'winget install failed. Install Tesseract manually.' -ForegroundColor Yellow
      $InstallExitCode = 2
    }
  } else {
    Write-Host 'Install Tesseract OCR manually and make sure tesseract.exe is in PATH.' -ForegroundColor Yellow
    $InstallExitCode = 2
  }
} else {
  $TesseractPath = if ($Tesseract.Source) { $Tesseract.Source } else { $Tesseract.FullName }
  Write-Host "Tesseract found: $TesseractPath" -ForegroundColor Green
}

if ($Python) {
  Write-Host 'Registering one-click OCR bridge...' -ForegroundColor Cyan
  & $Python "$Target\tools\ocr-bridge\install_bridge.py" --target $Target
  if ($LASTEXITCODE -ne 0) {
    Write-Host 'OCR bridge registration failed.' -ForegroundColor Red
    $InstallExitCode = 2
  }
}

Write-Host ''
if ($InstallExitCode -eq 0) {
  Write-Host 'Installed.' -ForegroundColor Green
} else {
  Write-Host 'Tools were copied, but OCR dependencies need attention. See messages above.' -ForegroundColor Yellow
}
Write-Host "Open: $Target\launchers\open_leadbridge.bat"
Write-Host "OCR:  $Target\launchers\run_ocr_windows.bat"
Write-Host "Chrome extension folder: $Target\tools\max-chat-local-exporter"
Write-Host "Online amoCRM setup: $Target\integrations\google-apps-script-amocrm\README.md"
Read-Host 'Press Enter to exit'
exit $InstallExitCode
